import org.jfree.chart.ChartFactory;
import org.jfree.chart.ChartPanel;
import org.jfree.chart.JFreeChart;
import org.jfree.chart.plot.PlotOrientation;
import org.jfree.data.category.DefaultCategoryDataset;

import javax.swing.*;
import java.sql.*;
import java.time.LocalDate;

public class ProductionGraphique {

    // Méthode pour afficher le graphique de production depuis la base de données
    public static JPanel afficherGraphiqueProduction(LocalDate debut, LocalDate fin) {
        // Créer un jeu de données
        DefaultCategoryDataset dataset = new DefaultCategoryDataset();

        // Connexion à la base de données pour récupérer les données de production
        Connection connection = getConnection.getConnection();

        if (connection != null) {
            String sql = "SELECT date_production, quantite_energie FROM Productions WHERE date_production BETWEEN ? AND ?";

            try (PreparedStatement statement = connection.prepareStatement(sql)) {
                // Définir les paramètres de la requête
                statement.setDate(1, Date.valueOf(debut));
                statement.setDate(2, Date.valueOf(fin));

                // Exécuter la requête
                try (ResultSet resultSet = statement.executeQuery()) {
                    // Ajouter les données de production au dataset
                    while (resultSet.next()) {
                        LocalDate dateProduction = resultSet.getDate("date_production").toLocalDate();
                        double quantiteEnergie = resultSet.getDouble("quantite_energie");

                        // Ajouter la valeur au dataset
                        dataset.addValue(quantiteEnergie, "Production d'énergie", dateProduction.toString());
                    }
                }
            } catch (SQLException e) {
                System.out.println("Erreur lors de la récupération des données de production");
                e.printStackTrace();
            } finally {
                try {
                    connection.close(); // Fermer la connexion après utilisation
                } catch (SQLException e) {
                    e.printStackTrace();
                }
            }
        }

        // Créer le graphique avec JFreeChart
        JFreeChart chart = ChartFactory.createLineChart(
                "Graphique de Production d'Énergie", // Titre du graphique
                "Date", // Nom de l'axe X
                "Quantité d'Énergie (kWh)", // Nom de l'axe Y
                dataset, // Données
                PlotOrientation.VERTICAL, // Orientation
                true, // Inclure la légende
                true, // Infos bulle (tooltips)
                false // URLs
        );

        // Créer un panneau contenant le graphique
        ChartPanel chartPanel = new ChartPanel(chart);
        chartPanel.setPreferredSize(new java.awt.Dimension(800, 600));

        // Retourner le JPanel contenant le graphique
        return chartPanel;
    }
}
