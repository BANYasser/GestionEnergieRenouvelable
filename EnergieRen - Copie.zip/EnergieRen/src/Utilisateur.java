import java.time.LocalDate;
import java.util.ArrayList;
import java.util.List;

public class Utilisateur {
    public String nom;                      // Nom de l'utilisateur
    public String adresse;                  // Adresse de l'utilisateur
    public List<Installation> installations; // Liste des installations associées à l'utilisateur

    // Constructeur
    public Utilisateur(String nom, String adresse, List<Installation> installations) {
        this.nom = nom;
        this.adresse = adresse;
        this.installations =  new ArrayList<>(); // Initialisation de la liste des installations
    }

    // Ajouter une installation
    public void ajouterInstallation(Installation installation) {
        installations.add(installation);
        System.out.println("Installation ajoutée : " + installation.getTypeInstallation());
    }

    // Modifier une installation (par exemple en fonction de son ID)
    public void setmodifierInstallation(int idmodifier, int NouvelID,String nouveauType,String nouvelleLocalisation, double nouvelleCapacite) {
        // Vérifier la validité des paramètres avant d'effectuer la modification
        if (idmodifier <= 0 ||NouvelID <= 0) {
            throw new IllegalArgumentException("L'ID doit être un nombre positif.");
        }
        if (nouvelleLocalisation == null || nouvelleLocalisation.trim().isEmpty()) {
            throw new IllegalArgumentException("La localisation ne peut pas être vide.");
        }
        if (nouveauType == null || nouveauType.trim().isEmpty()) {
            throw new IllegalArgumentException("Le type d'installation ne peut pas être vide.");
        }
        if (nouvelleCapacite < 0) {
            throw new IllegalArgumentException("La capacité de production doit être positive.");
        }
        System.out.println("Recherche de l'installation avec ID : " + idmodifier); // Impression pour le débogage

        boolean trouve = false;
        for (Installation installation : installations) {
            System.out.println("Verification de l'installation avec ID : " + installation.getID()); // Impression pour le débogage

            if (installation.getID() == idmodifier) {
                installation.setID(NouvelID); // Utiliser les setters pour modifier les attributs
                installation.setLocalisation(nouvelleLocalisation);
                installation.setTypeInstallation(nouveauType);
                installation.setCapaciteProduction(nouvelleCapacite);
                installation.setDateInstallation(LocalDate.now());
                System.out.println("Installation " + idmodifier + " modifiée à " + nouvelleLocalisation + " avec succès");
                trouve = true;
                break;
            }
        } if (!trouve){
            System.out.println("Aucune installation trouvée avec l'ID " + idmodifier);}
    }
    // Supprimer une installation
    public void supprimerInstallation(int ID) {
        for (int i = 0; i < installations.size(); i++) {
            if (installations.get(i).getID() == ID) {
                installations.remove(i);
                System.out.println("L'installation avec l'ID " + ID + " supprimée avec succès.");
                return; // Sortir de la méthode après la suppression
            }
        }
        System.out.println("Aucune installation trouvée avec l'ID " + ID + ".");
    }
    // Afficher la liste des installations
    public void afficherInstallations() {
        if (installations.isEmpty()) {
            System.out.println("Aucune installation disponible.");
        } else {
            for (Installation installation : installations) {
                System.out.println("ID:" +installation.getID() + ", Type: " + installation.getTypeInstallation() + ", Capacité: " + installation.getCapaciteProduction() + " kW, Localisation: " + installation.getLocalisation() + " Date d'installation:" + installation.getDateInstallation());
            }
        }
    }
}




