import java.sql.*;

public class InstallationBD {

    // Méthode pour ajouter une nouvelle installation
    public static void ajouterInstallation(int id, String type, String localisation, double capacite, String dateInstallation) {
        // Vérification des données d'entrée
        if (type == null || type.isEmpty() || localisation == null || localisation.isEmpty() || capacite <= 0 || dateInstallation == null || dateInstallation.isEmpty()) {
            System.out.println("Erreur : Tous les champs doivent être remplis avec des valeurs valides.");
            return; // Sortir de la méthode si les données sont invalides
        }

        String sql = "INSERT INTO installations (id, type, localisation, capacite, date_installation) VALUES (?, ?, ?, ?, ?)";

        try (Connection conn = getConnection.getConnection();
             PreparedStatement pstmt = conn.prepareStatement(sql)) {

            pstmt.setInt(1, id);
            pstmt.setString(2, type);
            pstmt.setString(3, localisation);
            pstmt.setDouble(4, capacite);
            pstmt.setString(5, dateInstallation);
            pstmt.executeUpdate();
            System.out.println("Installation ajoutée avec succès !");

        } catch (SQLException e) {
            // Gestion des erreurs SQL
            if (e.getErrorCode() == 1062) { // Code d'erreur pour les doublons
                System.out.println("Erreur : Une installation avec cet ID existe déjà.");
            } else {
                System.out.println("Erreur lors de l'ajout de l'installation : " + e.getMessage());
            }
        }
    }


    // Méthode pour modifier une installation
    public static void modifierInstallation(int idModifier, int nouvelID, String nouveauType, String nouvelleLocalisation, double nouvelleCapacite) {
        Connection connection = getConnection.getConnection();

        if (connection != null) {
            String sql = "UPDATE Installations SET id = ?, type = ?, localisation = ?, capacite_production = ? WHERE id = ?";

            try (PreparedStatement statement = connection.prepareStatement(sql)) {
                // Définir les paramètres de la requête
                statement.setInt(1, nouvelID);
                statement.setString(2, nouveauType);
                statement.setString(3, nouvelleLocalisation);
                statement.setDouble(4, nouvelleCapacite);
                statement.setInt(5, idModifier);

                // Exécuter la requête
                int rowsUpdated = statement.executeUpdate();
                if (rowsUpdated > 0) {
                    System.out.println("L'installation avec l'ID " + idModifier + " a été modifiée avec succès.");
                } else {
                    System.out.println("Aucune installation trouvée avec l'ID " + idModifier + ".");
                }
            } catch (SQLException e) {
                System.out.println("Erreur lors de la modification de l'installation");
                e.printStackTrace();
            } finally {
                try {
                    connection.close(); // Fermer la connexion après utilisation
                } catch (SQLException e) {
                    e.printStackTrace();
                }
            }
        }
    }
    // Méthode pour supprimer une installation
    public static void supprimerInstallation(int ID) {
        Connection connection = getConnection.getConnection();

        if (connection != null) {
            String sql = "DELETE FROM Installations WHERE id = ?";

            try (PreparedStatement statement = connection.prepareStatement(sql)) {
                // Définir le paramètre de la requête
                statement.setInt(1, ID);

                // Exécuter la requête
                int rowsDeleted = statement.executeUpdate();
                if (rowsDeleted > 0) {
                    System.out.println("L'installation avec l'ID " + ID + " a été supprimée avec succès.");
                } else {
                    System.out.println("Aucune installation trouvée avec l'ID " + ID + ".");
                }
            } catch (SQLException e) {
                System.out.println("Erreur lors de la suppression de l'installation");
                e.printStackTrace();
            } finally {
                try {
                    connection.close(); // Fermer la connexion après utilisation
                } catch (SQLException e) {
                    e.printStackTrace();
                }
            }
        }
    }
    // Méthode pour lire les installations
    public static void listerInstallations() {
        Connection connection = getConnection.getConnection();

        if (connection != null) {
            String sql = "SELECT * FROM Installations";

            try (Statement statement = connection.createStatement();
                 ResultSet resultSet = statement.executeQuery(sql)) {

                while (resultSet.next()) {
                    int id = resultSet.getInt("id");
                    String type = resultSet.getString("type");
                    String localisation = resultSet.getString("localisation");
                    double capacite = resultSet.getDouble("capacite_production");
                    String dateInstallation = resultSet.getString("date_installation");

                    System.out.println("ID: " + id + ",Type: " + type + ", Localisation: " + localisation + ", Capacité: " + capacite + " kWh, Date d'installation: " + dateInstallation);
                }

            } catch (SQLException e) {
                System.out.println("Erreur lors de la lecture des installations");
                e.printStackTrace();
            } finally {
                try {
                    connection.close(); // Fermer la connexion après utilisation
                } catch (SQLException e) {
                    e.printStackTrace();
                }
            }
        }
    }
}

