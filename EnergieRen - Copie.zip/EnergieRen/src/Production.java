import java.time.LocalDate;
import java.util.ArrayList;
import java.util.List;
import org.jfree.chart.ChartFactory;
import org.jfree.chart.ChartPanel;
import org.jfree.chart.JFreeChart;
import org.jfree.chart.plot.PlotOrientation;
import org.jfree.data.category.DefaultCategoryDataset;
import javax.swing.*;

public class Production {
    // Attributs
    private LocalDate dateProduction;
    private double quantiteEnergie; // en kWh
    private String installationAssociee;
    private static List<Production> listeProductions = new ArrayList<>(); // Liste partagée par toutes les instances

    // Constructeur
    public Production(LocalDate dateProduction, double quantiteEnergie, String installationAssociee) {
        this.dateProduction = dateProduction;
        this.quantiteEnergie = quantiteEnergie;
        this.installationAssociee = installationAssociee;
    }

    // Getters et Setters
    public String getInstallationAssociee() {
        return installationAssociee;
    }

   /* public void setInstallationAssociee() {
        this.installationAssociee = installationAssociee;
    }*/
    public LocalDate getDateProduction() {
        return dateProduction;
    }

    public void setDateProduction(LocalDate dateProduction) {
        this.dateProduction = dateProduction;
    }

    public double getQuantiteEnergie() {
        return quantiteEnergie;
    }

    public void setQuantiteEnergie(double quantiteEnergie) {
        this.quantiteEnergie = quantiteEnergie;
    }

    // Méthode pour afficher les informations de production
    public void afficherDetails() {
        System.out.println("Date de production : " + dateProduction);
        System.out.println("Quantité d'énergie produite (kWh) : " + quantiteEnergie);
        System.out.println("Installation associée : " + installationAssociee);
    }

    // Enregistrer un relevé de production
    public static void enregistrerProduction(Production production) {
        listeProductions.add(production);
        System.out.println("Relevé de production enregistré.");
    }

    // Afficher l'historique de production
    public static void afficherHistorique() {
        if (listeProductions.isEmpty()) {
            System.out.println("Aucun relevé de production disponible.");
        } else {
            System.out.println("Historique des relevés de production :");
            for (Production production : listeProductions) {
                production.afficherDetails();
                System.out.println("-------------------------------");
            }
        }
    }
    // Calculer la production totale sur une période donnée
    public static double calculerProductionTotale(LocalDate debut, LocalDate fin) {
        double total = 0;
        for (Production production : listeProductions) {
            if (!production.getDateProduction().isBefore(debut) && !production.getDateProduction().isAfter(fin)) {
                total += production.getQuantiteEnergie();
            }
        }
        return total;
    }
    // Méthode pour afficher un graphique de la production d'énergie au fil du temps
    public static void afficherGraphiqueProduction() {
        // Vérifie si la liste de productions est vide
        if (listeProductions.isEmpty()) {
            System.out.println("Aucune donnée de production disponible pour afficher un graphique.");
            return;
        }

        // Créer un jeu de données
        DefaultCategoryDataset dataset = new DefaultCategoryDataset();
        for (Production production : listeProductions) {
            // Ajoute la quantité d'énergie avec la date de production comme clé
            dataset.addValue(production.getQuantiteEnergie(), "Production", production.getDateProduction().toString());
        }

        // Créer le graphique en ligne
        JFreeChart lineChart = ChartFactory.createLineChart(
                "Courbe de Production d'Énergie", // Titre
                "Date", // Axe X
                "Quantité d'énergie (kWh)", // Axe Y
                dataset, // Données
                PlotOrientation.VERTICAL,
                true, true, false);

        // Afficher le graphique dans un panneau
        ChartPanel chartPanel = new ChartPanel(lineChart);
        chartPanel.setPreferredSize(new java.awt.Dimension(800, 600));

        // Créer une fenêtre pour afficher le graphique
        JFrame frame = new JFrame("Graphique de Production");
        frame.setContentPane(chartPanel);
        frame.pack();
        frame.setVisible(true);
    }
    public static double calculerRendement(double energieProduite, double capaciteMax) {
        if (capaciteMax <= 0) {
            return 0; // Éviter la division par zéro
        }
        return (energieProduite / capaciteMax) * 100; // Renvoie le rendement en pourcentage
    }

    public static Production trouverPicProduction() {
        Production pic = null;
        for (Production production : listeProductions) {
            if (pic == null || production.getQuantiteEnergie() > pic.getQuantiteEnergie()) {
                pic = production;
            }
        }
        return pic;
    }
    public static double estimerEconomies(double coutParKWh) {
        double energieTotaleProduite = calculerProductionTotale(LocalDate.MIN, LocalDate.MAX);
        return energieTotaleProduite * coutParKWh;
    }

}
