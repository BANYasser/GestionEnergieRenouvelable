
    package com.example.demo1;

import javafx.application.Application;
import javafx.fxml.FXMLLoader;
import javafx.scene.Parent;
import javafx.scene.Scene;
import javafx.stage.Stage;

    public class Main1 extends Application {

        @Override
        public void start(Stage primaryStage) throws Exception {
            // Charger le fichier FXML de la fenêtre de connexion
            Parent root = FXMLLoader.load(getClass().getResource("Login.fxml")); // Assurez-vous que le chemin est correct
            primaryStage.setTitle("Application de Connexion");
            primaryStage.setScene(new Scene(root, 400, 300)); // Ajustez la taille selon vos besoins
            primaryStage.show();
        }

        public static void main(String[] args) {
            launch(args);
        }
    }


