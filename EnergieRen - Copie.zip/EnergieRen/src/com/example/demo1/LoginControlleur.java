package com.example.demo1;

import javafx.fxml.FXML;
import javafx.scene.control.Button;
import javafx.scene.control.Label;
import javafx.scene.control.TextField;
import javafx.scene.Scene;
import javafx.stage.Stage;
import javafx.fxml.FXMLLoader;
import java.io.IOException;

public class LoginControlleur {

    @FXML
    private Label welcomeText;

    @FXML
    private TextField nomField; // Champ pour le nom

    @FXML
    private TextField adresseField; // Champ pour l'adresse

    @FXML
    private Button connexionButton; // Bouton de connexion

    // Méthode qui est appelée lors du clic sur le bouton "Connexion"
    @FXML
    private void onConnexionButtonClick() {
        // Récupérer les valeurs saisies dans les champs de texte
        String nom = nomField.getText();
        String adresse = adresseField.getText();

        // Vérifier si l'utilisateur est dans la base de données
        if (verifierUtilisateur(nom, adresse)) {
            // Ouvrir la fenêtre du menu si les informations sont valides
            ouvrirFenetreMenu();
        } else {
            // Afficher un message d'erreur si les informations sont incorrectes
            welcomeText.setText("Informations incorrectes !");
        }
    }

    // Méthode pour vérifier les informations de l'utilisateur dans la base de données
    private boolean verifierUtilisateur(String nom, String adresse) {
        // Ici, vous devez ajouter le code pour vérifier l'utilisateur dans la base de données
        // Par exemple, en exécutant une requête SQL et en retournant true si l'utilisateur existe
        // Cela pourrait ressembler à :
        // return DatabaseUtil.verifierUtilisateur(nom, adresse);

        // Pour l'instant, nous allons simuler une vérification réussie :
        return nom.equals("utilisateur") && adresse.equals("adresse@example.com");
    }

    // Méthode pour ouvrir la fenêtre du menu
    private void ouvrirFenetreMenu() {
        try {
            // Charger le fichier FXML de la fenêtre du menu
            FXMLLoader loader = new FXMLLoader(getClass().getResource("Menu.fxml")); // Remplacez par le chemin de votre fichier Menu.fxml
            Scene scene = new Scene(loader.load());
            Stage stage = (Stage) connexionButton.getScene().getWindow(); // Récupérer la fenêtre actuelle
            stage.setScene(scene); // Changer la scène vers la fenêtre du menu
            stage.setTitle("Menu"); // Titre de la nouvelle fenêtre
            stage.show(); // Afficher la nouvelle fenêtre
        } catch (IOException e) {
            e.printStackTrace();
        }
    }
}
