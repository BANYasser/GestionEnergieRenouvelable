import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.SQLException;

public class getConnection {
    private static final String URL = "jdbc:mysql://localhost:3306/energie"; // Remplace 'energie' par le nom de ta base de données
    private static final String USER = "root"; // Ton nom d'utilisateur MySQL
    private static final String PASSWORD = "ggNssWQvE@2024"; // Ton mot de passe MySQL

    public static Connection getConnection() {
        try {
            // Connexion à la base de données
            Connection connection = DriverManager.getConnection(URL, USER, PASSWORD);
            System.out.println("Connexion à la base de données réussie");
            return connection;
        } catch (SQLException e) {
            System.out.println("Erreur de connexion à la base de données");
            e.printStackTrace();
            return null;
        }
       }
    }