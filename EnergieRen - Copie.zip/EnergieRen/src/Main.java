import javax.swing.*;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.SQLException;
import java.time.LocalDate;
import java.time.format.DateTimeParseException;
import java.util.InputMismatchException;
import java.util.Scanner;

public class Main {
    // Classe pour gérer la connexion à la base de données
    public static Connection getConnection() {
        String url = "jdbc:mysql://localhost:3306/energie"; // Remplacez par l'URL de votre base de données
        String user = "root"; // Remplacez par votre nom d'utilisateur
        String password = "ggNssWQvE@2024"; // Remplacez par votre mot de passe

        try {
            return DriverManager.getConnection(url, user, password);
        } catch (SQLException e) {
            System.out.println("Erreur lors de la connexion à la base de données");
            e.printStackTrace();
            return null;
        }
    }

    // Programme principal
    public static void main(String[] args) {
        Scanner scanner = new Scanner(System.in);
        int choix;

        do {
            System.out.println("\nMenu :");
            System.out.println("1. Ajouter une installation");
            System.out.println("2. Modifier une installation");
            System.out.println("3. Supprimer une installation");
            System.out.println("4. Lister les installations");
            System.out.println("5. Enregistrer une production");
            System.out.println("6. Afficher l'historique des productions");
            System.out.println("7. Calculer la production totale");
            System.out.println("8. Trouver le pic de production");
            System.out.println("9. Afficher le graphique de production"); // Nouvelle option
            System.out.println("0. Quitter");
            System.out.print("Choisissez une option : ");
            choix = scanner.nextInt();
            scanner.nextLine(); // Consommer le saut de ligne

            switch (choix) {
                case 1:
                    try {
                        System.out.print("Entrez l'ID de l'installation : ");
                        int id = scanner.nextInt();
                        scanner.nextLine(); // Consommer le saut de ligne

                        System.out.print("Entrez le type de l'installation : ");
                        String type = scanner.nextLine();

                        System.out.print("Entrez la localisation : ");
                        String localisation = scanner.nextLine();

                        System.out.print("Entrez la capacité de production (en kWh) : ");
                        double capacite = scanner.nextDouble();
                        scanner.nextLine(); // Consommer le saut de ligne

                        System.out.print("Entrez la date d'installation (format AAAA-MM-JJ) : ");
                        String dateInstallation = scanner.nextLine();

                        // Validation de la date
                        LocalDate.parse(dateInstallation); // Cela lancera une exception si la date n'est pas valide

                        InstallationBD.ajouterInstallation(id, type, localisation, capacite, dateInstallation);
                        System.out.println("Installation ajoutée avec succès !");
                    } catch (InputMismatchException e) {
                        System.out.println("Erreur : Veuillez entrer des valeurs valides.");
                        scanner.next(); // Consomme l'entrée incorrecte
                    } catch (DateTimeParseException e) {
                        System.out.println("Erreur : Format de date invalide, veuillez utiliser AAAA-MM-JJ.");
                    }
                    break;


                case 2:
                    System.out.print("Entrez l'ID de l'installation à modifier : ");
                    int idModifier = scanner.nextInt();
                    scanner.nextLine(); // Consommer le saut de ligne

                    System.out.print("Entrez le nouvel ID : ");
                    int nouvelID = scanner.nextInt();
                    scanner.nextLine(); // Consommer le saut de ligne

                    System.out.print("Entrez le nouveau type : ");
                    String nouveauType = scanner.nextLine();

                    System.out.print("Entrez la nouvelle localisation : ");
                    String nouvelleLocalisation = scanner.nextLine();

                    System.out.print("Entrez la nouvelle capacité de production : ");
                    double nouvelleCapacite = scanner.nextDouble();
                    scanner.nextLine(); // Consommer le saut de ligne

                    InstallationBD.modifierInstallation(idModifier, nouvelID, nouveauType, nouvelleLocalisation, nouvelleCapacite);
                    break;

                case 3:
                    System.out.print("Entrez l'ID de l'installation à supprimer : ");
                    int idSupprimer = scanner.nextInt();
                    scanner.nextLine(); // Consommer le saut de ligne

                    InstallationBD.supprimerInstallation(idSupprimer);
                    break;

                case 4:
                    InstallationBD.listerInstallations();
                    break;
                case 5:
                    // Ajouter la fonctionnalité pour enregistrer une production
                    System.out.print("Entrez la date de production (format AAAA-MM-JJ) : ");
                    String dateProduction = scanner.nextLine();

                    System.out.print("Entrez la quantité d'énergie produite (en kWh) : ");
                    double quantiteEnergie = scanner.nextDouble();
                    scanner.nextLine(); // Consommer le saut de ligne

                    System.out.print("Entrez l'installation associée : ");
                    String installationAssociee = scanner.nextLine();

                    Production production = new Production(LocalDate.parse(dateProduction), quantiteEnergie, installationAssociee);
                    ProductionBD.enregistrerProduction(production);
                    break;
                case 6:
                    // Afficher l'historique des productions
                    ProductionBD.afficherHistorique();
                    break;
                case 7:
                    // Calculer la production totale sur une période
                    System.out.print("Entrez la date de début (AAAA-MM-JJ) : ");
                    LocalDate dateDebut = LocalDate.parse(scanner.nextLine());

                    System.out.print("Entrez la date de fin (AAAA-MM-JJ) : ");
                    LocalDate dateFin = LocalDate.parse(scanner.nextLine());

                    double productionTotale = ProductionBD.calculerProductionTotale(dateDebut, dateFin);
                    System.out.println("Production totale entre " + dateDebut + " et " + dateFin + ": " + productionTotale + " kWh");
                    break;
                case 8:
                    // Trouver le pic de production
                    Production picProduction = ProductionBD.trouverPicProduction();
                    if (picProduction != null) {
                        System.out.println("Pic de production : " + picProduction.getQuantiteEnergie() + " kWh le " + picProduction.getDateProduction());
                    } else {
                        System.out.println("Aucune production trouvée.");
                    }
                    break;
                case 9:
                    // Afficher le graphique de production
                    System.out.print("Entrez la date de début pour le graphique (AAAA-MM-JJ) : ");
                    LocalDate dateDebutGraphique = LocalDate.parse(scanner.nextLine());

                    System.out.print("Entrez la date de fin pour le graphique (AAAA-MM-JJ) : ");
                    LocalDate dateFinGraphique = LocalDate.parse(scanner.nextLine());

                    // Créer et afficher le graphique
                    JPanel graphique = ProductionGraphique.afficherGraphiqueProduction(dateDebutGraphique, dateFinGraphique);
                    JFrame frame = new JFrame("Graphique de Production");
                    frame.setDefaultCloseOperation(JFrame.DISPOSE_ON_CLOSE);
                    frame.getContentPane().add(graphique);
                    frame.pack();
                    frame.setLocationRelativeTo(null); // Centrer la fenêtre
                    frame.setVisible(true);
                    break;
                case 0:
                    System.out.println("Agréable suite !");
                    break;
                default:
                    System.out.println("Choix invalide, veuillez réessayer.");
                    break;
            }
        } while (choix != 0);

        scanner.close();
    }

}
