import java.time.LocalDate;
public class Installation {
    private String typeInstallation;
    private double capaciteProduction;
    private String localisation;
    private LocalDate dateInstallation;
    private int ID ;


    // Constructeurs,
    public Installation(int ID, String typeInstallation, double capaciteProduction, String localisation, LocalDate dateInstallation){
        if (ID <= 0) {
            throw new IllegalArgumentException("L'ID doit être un nombre positif.");
        }
        if (capaciteProduction < 0) {
            throw new IllegalArgumentException("La capacité de production ne peut pas être négative.");
        }
        if (typeInstallation == null || typeInstallation.isEmpty()) {
            throw new IllegalArgumentException("Le type d'installation ne peut pas être vide.");
        }
        if (localisation == null || localisation.isEmpty()) {
            throw new IllegalArgumentException("La localisation ne peut pas être vide.");
        }
        if (dateInstallation == null) {
            throw new IllegalArgumentException("La date d'installation ne peut pas être nulle.");
        }

        this.ID = ID;
        this.typeInstallation = typeInstallation;
        this.capaciteProduction = capaciteProduction;
        this.localisation = localisation;
        this.dateInstallation = LocalDate.now();
    }
    // Getter pour ID
    public int getID() {
        return ID;
    }
    // Getter pour typeInstallation
    public String getTypeInstallation() {
        return typeInstallation;
    }
    // Getter pour localisation
    public String getLocalisation() {
        return localisation;
    }
    //Getter pour capacite
    public double getCapaciteProduction() {
            return capaciteProduction;
        }
        //Getter pour DateInstallation
        public LocalDate getDateInstallation() {
            return dateInstallation;
        }

        // Getters de name
        public String getNom() {
            return typeInstallation;
        }

        public void setID(int NouvelID) {
            this.ID = NouvelID;
        }
        // Setter localisation
        public void setLocalisation(String localisation) {
            this.localisation = localisation;
        }
        // setter typeInstallation
        public void setTypeInstallation(String nouveauType) {
            this.typeInstallation = nouveauType;
        }
        // Setter CapacitéProduite
        public void setCapaciteProduction(double nouvelleCapacite) {
            this.capaciteProduction = nouvelleCapacite;
        }
        // Setter pour la MAJ date
        public void setDateInstallation(LocalDate dateInstallation) {
            this.dateInstallation = dateInstallation;
        }


    }












