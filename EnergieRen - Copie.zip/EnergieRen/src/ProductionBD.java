
import java.sql.*;
import java.time.LocalDate;

public class ProductionBD {

    // ENREGISTRER UN RELEVE DE PRODUCTION
    public static void enregistrerProduction(Production production) {
    Connection connection = getConnection.getConnection();

    if (connection != null) {
        String sql = "INSERT INTO Productions (date_production, quantite_energie, installation_associee) VALUES (?, ?, ?)";

        try (PreparedStatement statement = connection.prepareStatement(sql)) {
            // Définir les paramètres de la requête
            statement.setDate(1, java.sql.Date.valueOf(production.getDateProduction()));
            statement.setDouble(2, production.getQuantiteEnergie());
            statement.setString(3, production.getInstallationAssociee());

            // Exécuter la requête
            int rowsInserted = statement.executeUpdate();
            if (rowsInserted > 0) {
                System.out.println("La production a été enregistrée avec succès !");
            }
        } catch (SQLException e) {
            System.out.println("Erreur lors de l'enregistrement de la production");
            e.printStackTrace();
        } finally {
            try {
                connection.close(); // Fermer la connexion après utilisation
            } catch (SQLException e) {
                e.printStackTrace();
            }
        }
    }
  }
  // AFICHER LES HISTORIQUES DE RELEVES

    public static void afficherHistorique() {
        Connection connection = getConnection.getConnection();

        if (connection != null) {
            String sql = "SELECT * FROM Productions";

            try (Statement statement = connection.createStatement();
                 ResultSet resultSet = statement.executeQuery(sql)) {

                while (resultSet.next()) {
                    int id = resultSet.getInt("ID");
                    Date dateProduction = resultSet.getDate("date_production");
                    double quantiteEnergie = resultSet.getDouble("quantite_energie");
                    String installationAssociee = resultSet.getString("installation_associee");

                    System.out.println("ID: " + id + ", Date: " + dateProduction + ", Quantité: " + quantiteEnergie + " kWh, Installation: " + installationAssociee);
                }

            } catch (SQLException e) {
                System.out.println("Erreur lors de l'affichage de l'historique des productions");
                e.printStackTrace();
            } finally {
                try {
                    connection.close(); // Fermer la connexion après utilisation
                } catch (SQLException e) {
                    e.printStackTrace();
                }
            }
        }
    }
    // CALCUL DE ENERGIE TOTALE
    public static double calculerProductionTotale(LocalDate debut, LocalDate fin) {
        Connection connection = getConnection.getConnection();
        double totalEnergie = 0;

        if (connection != null) {
            String sql = "SELECT SUM(quantite_energie) FROM Productions WHERE date_production BETWEEN ? AND ?";

            try (PreparedStatement statement = connection.prepareStatement(sql)) {
                statement.setDate(1, java.sql.Date.valueOf(debut));
                statement.setDate(2, java.sql.Date.valueOf(fin));

                ResultSet resultSet = statement.executeQuery();
                if (resultSet.next()) {
                    totalEnergie = resultSet.getDouble(1);
                }

            } catch (SQLException e) {
                System.out.println("Erreur lors du calcul de la production totale");
                e.printStackTrace();
            } finally {
                try {
                    connection.close(); // Fermer la connexion après utilisation
                } catch (SQLException e) {
                    e.printStackTrace();
                }
            }
        }

        return totalEnergie;
    }

    //  PIC DE PRODUCTION
    public static Production trouverPicProduction() {
        Production pic = null;
        Connection connection = getConnection.getConnection();

        if (connection != null) {
            String sql = "SELECT * FROM Productions ORDER BY quantite_energie DESC LIMIT 1";
            try (PreparedStatement statement = connection.prepareStatement(sql);
                 ResultSet resultSet = statement.executeQuery()) {
                if (resultSet.next()) {
                    // Créer l'objet Production à partir des données du ResultSet
                    pic = new Production(
                            resultSet.getDate("date_production").toLocalDate(), // Assurez-vous que le nom de la colonne est correct
                            resultSet.getDouble("quantite_energie"),
                            resultSet.getString("installation_associee")
                                        );
                }
            } catch (SQLException e) {
                System.out.println("Erreur lors de la recherche du pic de production");
                e.printStackTrace();
            } finally {
                try {
                    connection.close(); // Fermer la connexion après utilisation
                } catch (SQLException e) {
                    e.printStackTrace();
                }
            }
        }
        return pic;
    }
    public static double estimerEconomies(double coutParKWh, LocalDate debut, LocalDate fin) {
        double energieTotaleProduite = calculerProductionTotale(debut, fin);
        return energieTotaleProduite * coutParKWh;
    }

    }



